<?php
session_start();
$_SESSION['IDRole'] = 1;
$ROLE = $_SESSION['IDRole'];

if($ROLE != 1 || empty($ROLE)){
	header('location: acceuil.php');
}
$pdo = new PDO('mysql:host=localhost;dbname=parking', 'root', '');
?>

<!DOCTYPE html>
<!--
	Transit by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>PARKING | Admin</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="#">PARKING</a> | Administrateur</h1>
				<nav id="nav">
					<ul>
						<li><a href="logout.php"<i class="fa fa-sign-out fa-2x"></i></a></li>
					</ul>
				</nav>
			</header>

		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="container">

					<header class="major">
						<h2>Administration du Parking</h2>
						<p>Il y a actuellement {?} places dans le parking dont {?} occupées. <br/>
							Vous avez {?} demande(s) d'inscription en attente de validation.</p>
					</header>
				</div>
			</section>

			<section id="one" class="wrapper style1 special">
				<div class="container">
					<div class="row 150%">
						<div class="4u 12u$(medium)">
						<a class="tool" href="" onclick="<?php require('fonctions.php'); placeAdmin();?>"><section class="box">
								<i class="icon big rounded color1 fa-car"></i>
									<h3>Places</h3>
								<p></p>
							</section></a>
						</div>
						<div class="4u 12u$(medium)">
							<a class="tool" href="" onclick="bascule('utilisateur'); return false;"><section class="box">
								<i class="icon big rounded color9 fa-group"></i>
								<h3>Utilisateurs - <i class="fa fa-exclamation-circle" style="color:red;"></i></h3>
								<p></p>
							</section></a>
						</div>
						<div class="4u$ 12u$(medium)">
							<a class="tool" href="" onclick="bascule('attente'); return false;"><section class="box">
								<i class="icon big rounded color6 fa-sort-amount-asc"></i>
								<h3>Liste d'Attente</h3>
								<p></p>
							</section></a>
						</div>
					</div>
				</div>
			</section>

			<script language="javascript" type="text/javascript">
			function bascule(elem)
   		{
   			etat=document.getElementById(elem).style.display;
   			if(etat=="none"){
   				document.getElementById(elem).style.display="block";
   			}
   			else{
   				document.getElementById(elem).style.display="none";
   			}
   		}
			</script>



		<!-- Footer -->
			<footer id="footer">
				<div class="container">

					<div class="row">
						<div class="8u 12u$(medium)">
							<ul class="copyright">
								<li>&copy; Untitled. All rights reserved.</li>
								<li>Design: <a href="http://templated.co">TEMPLATED</a></li>
								<li>Images: <a href="http://unsplash.com">Unsplash</a></li>
							</ul>
						</div>
						<div class="4u$ 12u$(medium)">
							<ul class="icons">
								<li>
									<a class="icon rounded fa-facebook"><span class="label">Facebook</span></a>
								</li>
								<li>
									<a class="icon rounded fa-twitter"><span class="label">Twitter</span></a>
								</li>
								<li>
									<a class="icon rounded fa-google-plus"><span class="label">Google+</span></a>
								</li>
								<li>
									<a class="icon rounded fa-linkedin"><span class="label">LinkedIn</span></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>

	</body>
</html>
