<!DOCTYPE html>
<?php
  session_start();
  if (isset($_SESSION['connect']))//On vérifie que le variable existe.
{
        $connect=$_SESSION['connect'];//On récupère la valeur de la variable de session.
}
else
{
        $connect=0;//Si $_SESSION['connect'] n'existe pas, on donne la valeur "0".
}
       
if ($connect == "1" &&  $_SESSION['role'] == 1) // Si le visiteur s'est identifié.
{
// On affiche la page cachée.
?> 
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>PARKING | Admin</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="#">PARKING</a> | Administrateur</h1>
				<nav id="nav">
					<ul>
						<li><a href="logout.php"<i class="fa fa-sign-out fa-2x"></i></a></li>
					</ul>
				</nav>
			</header>

		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="container">
<?php
					$pdo = new PDO('mysql:host=localhost;dbname=parking', 'root', '');
					require('fonction.php');
					?>
					<header class="major">
						<h2>Administration du Parking</h2>
						<p>Il y a actuellement {?} places dans le parking dont {?} occupées. <br/>
							Vous avez {?} demande(s) d'inscription en attente de validation.</p>
					</header>
				</div>
			</section>

			<section id="one" class="wrapper style1 special">
				<div class="container">
					<div class="row 150%">
						<div class="4u 12u$(medium)">
							<a class="tool" href="#places"><section class="box">
								<i class="icon big rounded color1 fa-car"></i>
								<h3>Places</h3>
								<p></p>
							</section></a>
						</div>
						<div class="4u 12u$(medium)">
							<a class="tool" href="#user"><section class="box">
								<i class="icon big rounded color9 fa-group"></i>
								<h3>Utilisateurs - <i class="fa fa-exclamation-circle" style="color:red;"></i></h3>
								<p></p>
							</section></a>
						</div>
						<div class="4u$ 12u$(medium)">
							<a class="tool" href="#att"><section class="box">
								<i class="icon big rounded color6 fa-sort-amount-asc"></i>
								<h3>Liste d'Attente</h3>
								<p></p>
							</section></a>
						</div>
					</div>
				</div>
			</section>

		<div id="places">
			<section id="two" class="wrapper style2 special">
				<div class="container">
					<header class="major">
						<h2>Gestion des Places</h2>
						<p>Vous pouvez voir les <a href="#">Places Occupées</a>, consulter les <a href="#">Places Libres</a>,
							ou encore <a href="#">Editer</a> le Parking.</p>
					</header>
					<form>
						<input type="text" name="rch_park" placeholder="Rechercher une place..."/><br/>
						<input type="submit" name="btn_park" value="Recherche"/>
					</form>
					<pre><code style="text-align:left;">
//C'est pas une erreur, c'est fait exprès mes ptits plouks
req1="SELECT";

while($ligne){
//afficher les resultats...
}
					</code></pre>
				</div>
			</section>
		</div>

		<section id="one" class="wrapper style1 special">
			<div class="container">
			</div>
		</section>

		<div id="user">
			<section id="two" class="wrapper style2 special">
				<div class="container">
					<header class="major">
						<h2>Gestion des Utilisateurs</h2>
						<p>Vous pouvez voir les <a href="#">Demandes</a> d'Inscription en attente, ou <a href="#">Rechercher</a>,
							un Utilisateur.</p>
					</header>
					<form>
						<input type="text" name="rch_user" placeholder="Rechercher un utilisateur..."/><br/>
						<input type="submit" name="btn_user" value="Recherche"/>
					</form>
						<pre><code style="text-align:left;">
//C'est pas une erreur, c'est fait exprès mes ptits plouks
req1="SELECT";

while($ligne){
	//afficher les resultats...
}
						</code></pre>
						<p>Affichage type demande utilisateur :</p>
						<table>
							<tr>
								<th>Nom</th>
								<th>Prénom</th>
								<th>CP</th>
								<th>Immatriculation</th>
								<th>Mail</th>
								<th>Indicateurs</th>
								<th>
									<div class="wrap">
  									<input type="checkbox" id="s5" />
  									<label class="slider-v3" for="s5"></label>
									</div>
								</th>
							</tr>
							<tr>
	                        <?php
	                         $donnees = $pdo->query('SELECT * FROM utilisateur');
	                          while ($ligne = $donnees->fetch()) 
	                          { ?>
	                               <tr>
	                                   <td><?php echo $ligne['Nom']; ?></td>
	                                   <td><?php echo $ligne['Prenom']; ?></td>
	                                   <td><?php echo $ligne['CodePostal']; ?></td>
	                                    <td><?php echo $ligne['Immatriculation']; ?></td>
	                                    <td><?php echo $ligne['AdresseMail']; ?></td>
	                                    <td><?php echo "Indicateur"; ?></td>
	                                    <td>
	                                    	<div class="wrap">
		  									<input type="checkbox" id="s5" />
		  									<label class="slider-v3" for="s5"></label>
											</div>
									    </td>
	                                    
	                               </tr>
	                    <?php } ?>
						</table>
				</div>
			</section>
		</div>

		<section id="one" class="wrapper style1 special">
			<div class="container">
			</div>
		</section>

		<div id="att">
			<section id="two" class="wrapper style2 special">
				<div class="container">
					<header class="major">
						<h2>Liste d'Attente</h2>
						<p>Vous pouvez consulter la <a href="#">Liste</a> d'Attente, ou <a href="#">Rechercher</a>,
							un Utilisateur en Attente.</p>
					</header>
					<form>
						<input type="text" name="rch_att" placeholder="Rechercher un utilisateur..."/><br/>
						<input type="submit" name="btn_att" value="Recherche"/>
					</form>
					<pre><code style="text-align:left;">
//C'est pas une erreur, c'est fait exprès mes ptits plouks
req1="SELECT";

while($ligne){
//afficher les resultats...
}
					</code></pre>
				</div>
			</section>
		</div>

		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<section class="links">
						<div class="row">
							<section class="3u 6u(medium) 12u$(small)">
								<h3>Lorem ipsum dolor</h3>
								<ul class="unstyled">
									<li><a href="#">Lorem ipsum dolor sit</a></li>
									<li><a href="#">Nesciunt itaque, alias possimus</a></li>
									<li><a href="#">Optio rerum beatae autem</a></li>
									<li><a href="#">Nostrum nemo dolorum facilis</a></li>
									<li><a href="#">Quo fugit dolor totam</a></li>
								</ul>
							</section>
							<section class="3u 6u$(medium) 12u$(small)">
								<h3>Culpa quia, nesciunt</h3>
								<ul class="unstyled">
									<li><a href="#">Lorem ipsum dolor sit</a></li>
									<li><a href="#">Reiciendis dicta laboriosam enim</a></li>
									<li><a href="#">Corporis, non aut rerum</a></li>
									<li><a href="#">Laboriosam nulla voluptas, harum</a></li>
									<li><a href="#">Facere eligendi, inventore dolor</a></li>
								</ul>
							</section>
							<section class="3u 6u(medium) 12u$(small)">
								<h3>Neque, dolore, facere</h3>
								<ul class="unstyled">
									<li><a href="#">Lorem ipsum dolor sit</a></li>
									<li><a href="#">Distinctio, inventore quidem nesciunt</a></li>
									<li><a href="#">Explicabo inventore itaque autem</a></li>
									<li><a href="#">Aperiam harum, sint quibusdam</a></li>
									<li><a href="#">Labore excepturi assumenda</a></li>
								</ul>
							</section>
							<section class="3u$ 6u$(medium) 12u$(small)">
								<h3>Illum, tempori, saepe</h3>
								<ul class="unstyled">
									<li><a href="#">Lorem ipsum dolor sit</a></li>
									<li><a href="#">Recusandae, culpa necessita nam</a></li>
									<li><a href="#">Cupiditate, debitis adipisci blandi</a></li>
									<li><a href="#">Tempore nam, enim quia</a></li>
									<li><a href="#">Explicabo molestiae dolor labore</a></li>
								</ul>
							</section>
						</div>
					</section>
					<div class="row">
						<div class="8u 12u$(medium)">
							<ul class="copyright">
								<li>&copy; Untitled. All rights reserved.</li>
								<li>Design: <a href="http://templated.co">TEMPLATED</a></li>
								<li>Images: <a href="http://unsplash.com">Unsplash</a></li>
							</ul>
						</div>
						<div class="4u$ 12u$(medium)">
							<ul class="icons">
								<li>
									<a class="icon rounded fa-facebook"><span class="label">Facebook</span></a>
								</li>
								<li>
									<a class="icon rounded fa-twitter"><span class="label">Twitter</span></a>
								</li>
								<li>
									<a class="icon rounded fa-google-plus"><span class="label">Google+</span></a>
								</li>
								<li>
									<a class="icon rounded fa-linkedin"><span class="label">LinkedIn</span></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>

	</body>
</html>
<?php  
}
else
{
 
   header('Location: index.php');
      exit();
}
?>